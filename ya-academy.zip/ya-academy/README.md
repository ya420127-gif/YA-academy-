# YA Academy — MVP Scaffold

منصة SaaS تعليمية متعددة المدرسين (Next.js 14 + Firebase Auth + Firestore).

## ما تم بناؤه فعليًا (يعمل)

- **فصل الأدوار الأربعة** (Owner/Admin/Teacher/Student) عبر **Firebase Custom Claims** — لا يُقرأ الدور أبدًا من مستند يمكن للعميل تعديله.
- **`firestore.rules`** كاملة تفرض RBAC حقيقي على مستوى الـ Database (Teacher A لا يرى Teacher B، Student محصور بمدرسه، إلخ).
- **حماية Owner ثلاثية الطبقات**:
  1. لا يوجد نموذج تسجيل owner في الواجهة إطلاقًا.
  2. `scripts/createOwner.mjs` — سكربت CLI وحيد لإنشاء أول Owner (يمنع تكرار الإنشاء).
  3. `/owner-login` صفحة غير مرتبطة من أي مكان + تتحقق من `role==owner` عبر `verifyIdToken` على السيرفر قبل منح كوكي جلسة httpOnly، ثم `middleware.ts` يحمي `/owner/*` على مستوى الـ Edge، بالإضافة إلى `RequireRole` على مستوى الواجهة.
- تدفق **Trial 3 أيام → Payment Request → موافقة Owner (عبر API route محمي بالكوكي) → تفعيل 30 يوم**.
- صفحات: Landing (RTL)، تسجيل مدرس، دخول مدرس، دخول طالب، Owner Dashboard (بالإحصائيات)، Teacher Dashboard (حالة الاشتراك + رابط المنصة).

## ما يحتاج استكمالًا (نفس النمط المستخدم أعلاه)

- صفحات: المواد، الدروس، صفحة الدرس (فيديو YouTube/Drive)، صفحة الطالب، `/teacher/:slug`، `/admin/*` الفرعية، الإشعارات، الإعدادات.
- **Cloud Function `onCreate`** لضبط custom claim `role: teacher` تلقائيًا بعد `createUserWithEmailAndPassword` في صفحة التسجيل (حاليًا الحساب يُنشأ في Auth+Firestore لكن ضبط الـ claim يحتاج Cloud Function أو استدعاء Admin SDK من API route مخصص — لم أفعّله هنا لتقليل النطاق).
- إنشاء حسابات الطلاب (تتم من المدرس عبر Admin SDK وليس Client SDK، لأن إنشاء مستخدم لا يُسجّل خروج المدرس الحالي).
- تحديث حالة `expired` تلقائيًا (Cloud Scheduler / Cron يوميًا يفحص `trialEndDate`/`subscriptionEndDate`).

## التشغيل محليًا

```bash
npm install
cp .env.example .env.local   # املأ متغيرات Firebase
firebase deploy --only firestore:rules
OWNER_EMAIL=you@x.com OWNER_PASSWORD='Strong!Pass1' npm run create-owner
npm run dev
```

سجّل دخول الـOwner من `/owner-login` (غير موجود في أي رابط بالواجهة).
