import { NextRequest, NextResponse } from "next/server";

/**
 * حماية إضافية على مستوى الـ Edge لمسارات /owner و /admin.
 * تعتمد على كوكي جلسة (__session) يحمل role موقّعًا من السيرفر عند تسجيل الدخول
 * (يُضبط في route handler خاص بتسجيل دخول Owner/Admin باستخدام Admin SDK).
 * هذه طبقة UX/دفاع إضافي — الحماية الفعلية النهائية هي firestore.rules.
 */
export function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname;

  const protectedPrefixes: Record<string, string[]> = {
    "/owner": ["owner"],
    "/admin": ["owner", "admin"],
  };

  const matched = Object.keys(protectedPrefixes).find((p) => path.startsWith(p));
  if (!matched) return NextResponse.next();

  const sessionRole = req.cookies.get("ya_role")?.value;

  if (!sessionRole || !protectedPrefixes[matched].includes(sessionRole)) {
    const url = req.nextUrl.clone();
    url.pathname = matched === "/owner" ? "/owner-login" : "/login";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/owner/:path*", "/admin/:path*"],
};
