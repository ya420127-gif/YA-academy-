"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/lib/firebase";

// ملاحظة: username/Student ID يُحوَّل داخليًا إلى بريد وهمي فريد عند إنشاء الطالب من المدرس
// مثال: <studentId>@students.ya-academy.app — هذا يسمح باستخدام Firebase Auth القياسي
export default function StudentLoginPage() {
  const router = useRouter();
  const [studentId, setStudentId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      const pseudoEmail = `${studentId.trim().toLowerCase()}@students.ya-academy.app`;
      await signInWithEmailAndPassword(auth, pseudoEmail, password);
      router.push("/student/dashboard");
    } catch {
      setError("رقم الطالب أو كلمة المرور غير صحيحة");
    }
  }

  return (
    <main className="max-w-sm mx-auto p-6 mt-16">
      <h1 className="text-xl font-bold mb-6">دخول الطلاب</h1>
      <form onSubmit={handleSubmit}>
        <input placeholder="Student ID / Username" required
          className="w-full border rounded-lg p-2 mb-3" value={studentId} onChange={(e) => setStudentId(e.target.value)} />
        <input type="password" placeholder="كلمة المرور" required
          className="w-full border rounded-lg p-2 mb-3" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <p className="text-red-600 text-sm mb-3">{error}</p>}
        <button className="w-full bg-indigo-600 text-white rounded-lg p-3">دخول</button>
      </form>
    </main>
  );
}
