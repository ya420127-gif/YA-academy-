"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

const TRIAL_DAYS = 3; // القيمة الافتراضية — تُقرأ لاحقًا من settings/global

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    fullName: "", displayName: "", phone: "", email: "",
    password: "", confirm: "", subject: "", stage: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (form.password !== form.confirm) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, form.email, form.password);

      const trialStart = new Date();
      const trialEnd = new Date(trialStart.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
      const slug = form.displayName.trim().toLowerCase().replace(/\s+/g, "-");

      // ملاحظة: هذا create يمر عبر firestore.rules → isSelf(teacherId) فقط، ولا يحدد role إطلاقًا
      // ضبط role='teacher' custom claim الفعلي يتم عبر Cloud Function onCreate (خارج نطاق هذا الملف)
      await setDoc(doc(db, "teachers", cred.user.uid), {
        fullName: form.fullName,
        displayName: form.displayName,
        slug,
        phone: form.phone,
        email: form.email,
        subject: form.subject,
        stage: form.stage,
        accountStatus: "trial",
        trialStartDate: trialStart.toISOString(),
        trialEndDate: trialEnd.toISOString(),
        subscriptionEndDate: null,
        createdAt: serverTimestamp(),
      });

      router.push("/teacher/dashboard");
    } catch (err: any) {
      setError(err.message ?? "حدث خطأ أثناء إنشاء الحساب");
    } finally {
      setLoading(false);
    }
  }

  const field = (k: keyof typeof form, label: string, type = "text") => (
    <div className="mb-4">
      <label className="block text-sm mb-1">{label}</label>
      <input
        type={type}
        required
        className="w-full border rounded-lg p-2"
        value={form[k]}
        onChange={(e) => setForm({ ...form, [k]: e.target.value })}
      />
    </div>
  );

  return (
    <main className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">إنشاء حساب مدرس</h1>
      <form onSubmit={handleSubmit}>
        {field("fullName", "الاسم بالكامل")}
        {field("displayName", "اسم المدرس الظاهر للطلاب")}
        {field("phone", "رقم الهاتف")}
        {field("email", "البريد الإلكتروني", "email")}
        {field("password", "كلمة المرور", "password")}
        {field("confirm", "تأكيد كلمة المرور", "password")}
        {field("subject", "المادة")}
        {field("stage", "المرحلة التعليمية")}
        {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
        <button disabled={loading} className="w-full bg-indigo-600 text-white rounded-lg p-3 font-semibold">
          {loading ? "جارٍ الإنشاء..." : "إنشاء الحساب وبدء التجربة المجانية"}
        </button>
      </form>
    </main>
  );
}
