"use client";

import { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import RequireRole from "@/components/RequireRole";

function daysLeft(iso: string) {
  const ms = new Date(iso).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / (1000 * 60 * 60 * 24)));
}

function TeacherDashboardInner() {
  const { user } = useAuth();
  const [teacher, setTeacher] = useState<any>(null);

  useEffect(() => {
    if (!user) return;
    getDoc(doc(db, "teachers", user.uid)).then((snap) => setTeacher(snap.data()));
  }, [user]);

  if (!teacher) return <div className="p-8">جارٍ التحميل...</div>;

  const isTrial = teacher.accountStatus === "trial";
  const isExpired = teacher.accountStatus === "expired";
  const link = `ya-academy.app/${teacher.slug}`;

  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-2">أهلًا، {teacher.displayName}</h1>

      {isTrial && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 my-4">
          متبقي على تجربتك المجانية: {daysLeft(teacher.trialEndDate)} يوم
        </div>
      )}

      {isExpired && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 my-4">
          <p className="font-semibold mb-2">انتهت تجربتك المجانية</p>
          <p className="text-sm mb-3">لتفعيل منصتك والاستمرار في استخدام YA Academy، قم بدفع 50 جنيهًا شهريًا.</p>
          <a href="/teacher/subscription" className="inline-block bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm">
            تفعيل الحساب
          </a>
        </div>
      )}

      <div className="bg-white border rounded-xl p-4 flex items-center justify-between mt-4">
        <span className="text-sm">{link}</span>
        <button
          onClick={() => navigator.clipboard.writeText(`https://${link}`)}
          className="text-sm border px-3 py-1 rounded-lg"
        >
          نسخ الرابط
        </button>
      </div>
    </main>
  );
}

export default function TeacherDashboard() {
  return (
    <RequireRole allow={["teacher"]}>
      <TeacherDashboardInner />
    </RequireRole>
  );
}
