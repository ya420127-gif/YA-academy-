import Link from "next/link";

// ملاحظة أمان: هذه الصفحة عمدًا لا تحتوي على أي رابط أو إشارة لـ /owner-login
export default function Home() {
  return (
    <main>
      <nav className="flex items-center justify-between p-6 max-w-6xl mx-auto">
        <span className="text-xl font-bold text-indigo-600">YA Academy</span>
        <div className="flex gap-3">
          <Link href="/login" className="px-4 py-2 rounded-lg border">دخول المدرسين</Link>
          <Link href="/student/login" className="px-4 py-2 rounded-lg border">دخول الطلاب</Link>
        </div>
      </nav>

      <section className="text-center py-20 px-6 max-w-3xl mx-auto">
        <h1 className="text-4xl font-extrabold mb-4">منصتك التعليمية في مكان واحد</h1>
        <p className="text-gray-600 mb-8">
          أنشئ منصتك التعليمية الخاصة خلال دقائق، أضف موادك ودروسك وطلابك، وشارك رابطك الخاص معهم.
        </p>
        <div className="flex justify-center gap-4">
          <Link href="/register" className="px-6 py-3 rounded-xl bg-indigo-600 text-white font-semibold">
            ابدأ مجانًا
          </Link>
          <Link href="/login" className="px-6 py-3 rounded-xl border font-semibold">
            دخول المدرسين
          </Link>
        </div>
      </section>

      <section className="max-w-5xl mx-auto grid md:grid-cols-3 gap-6 px-6 pb-20">
        {[
          ["سجّل مجانًا", "أنشئ حسابك واحصل على 3 أيام تجربة مجانية فورًا."],
          ["أضف محتواك", "مواد ودروس وفيديوهات وملخصات بسهولة."],
          ["شارك رابطك", "أرسل رابط منصتك الخاص لطلابك ليدخلوا مباشرة."],
        ].map(([title, desc]) => (
          <div key={title} className="p-6 bg-white rounded-xl border">
            <h3 className="font-bold mb-2">{title}</h3>
            <p className="text-sm text-gray-600">{desc}</p>
          </div>
        ))}
      </section>

      <section className="text-center pb-20">
        <h2 className="text-2xl font-bold mb-2">السعر</h2>
        <p className="text-gray-600">3 أيام تجربة مجانية، ثم 50 جنيهًا مصريًا شهريًا فقط.</p>
      </section>

      <footer className="text-center text-sm text-gray-400 py-8 border-t">
        © YA Academy — جميع الحقوق محفوظة
      </footer>
    </main>
  );
}
