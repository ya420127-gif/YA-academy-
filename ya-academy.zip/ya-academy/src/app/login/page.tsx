"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/lib/firebase";

export default function TeacherLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push("/teacher/dashboard");
    } catch {
      setError("بيانات الدخول غير صحيحة");
    }
  }

  return (
    <main className="max-w-sm mx-auto p-6 mt-16">
      <h1 className="text-xl font-bold mb-6">دخول المدرسين</h1>
      <form onSubmit={handleSubmit}>
        <input type="email" placeholder="البريد الإلكتروني" required
          className="w-full border rounded-lg p-2 mb-3" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="كلمة المرور" required
          className="w-full border rounded-lg p-2 mb-3" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <p className="text-red-600 text-sm mb-3">{error}</p>}
        <button className="w-full bg-indigo-600 text-white rounded-lg p-3">دخول</button>
      </form>
    </main>
  );
}
