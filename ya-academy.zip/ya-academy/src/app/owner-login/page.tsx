"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword, signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";

// هذه الصفحة غير مرتبطة من أي مكان في الموقع (لا Navbar ولا Footer ولا Landing Page)
// الوصول إليها فقط بمعرفة الرابط المباشر /owner-login
export default function OwnerLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      const tokenResult = await cred.user.getIdTokenResult(true);

      if (tokenResult.claims.role !== "owner") {
        // مستخدم عادي حاول الدخول من هنا — يُرفض فورًا حتى لو كانت بياناته صحيحة كمدرس/طالب
        await signOut(auth);
        setError("هذا الحساب غير مصرح له بالدخول من هنا");
        return;
      }

      // اطلب من السيرفر ضبط كوكي جلسة موقّع (يُستخدم في middleware.ts)
      await fetch("/api/owner/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ idToken: await cred.user.getIdToken() }),
      });

      router.push("/owner");
    } catch (err: any) {
      setError("بيانات الدخول غير صحيحة");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="max-w-sm mx-auto p-6 mt-16">
      <h1 className="text-xl font-bold mb-6">Owner Login</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="email" placeholder="Email" required
          className="w-full border rounded-lg p-2 mb-3"
          value={email} onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password" placeholder="Password" required
          className="w-full border rounded-lg p-2 mb-3"
          value={password} onChange={(e) => setPassword(e.target.value)}
        />
        {error && <p className="text-red-600 text-sm mb-3">{error}</p>}
        <button disabled={loading} className="w-full bg-gray-900 text-white rounded-lg p-3">
          {loading ? "..." : "Sign in"}
        </button>
      </form>
    </main>
  );
}
