"use client";

import { useEffect, useState } from "react";
import { collection, getCountFromServer, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import RequireRole from "@/components/RequireRole";

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="bg-white border rounded-xl p-5">
      <p className="text-sm text-gray-500 mb-1">{label}</p>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}

function OwnerDashboardInner() {
  const [stats, setStats] = useState({
    totalTeachers: 0, activeTeachers: 0, trialTeachers: 0, expiredTeachers: 0,
    totalStudents: 0, pendingPayments: 0,
  });

  useEffect(() => {
    async function load() {
      const teachersCol = collection(db, "teachers");
      const [total, active, trial, expired, students, pending] = await Promise.all([
        getCountFromServer(teachersCol),
        getCountFromServer(query(teachersCol, where("accountStatus", "==", "active"))),
        getCountFromServer(query(teachersCol, where("accountStatus", "==", "trial"))),
        getCountFromServer(query(teachersCol, where("accountStatus", "==", "expired"))),
        getCountFromServer(collection(db, "students")),
        getCountFromServer(query(collection(db, "paymentRequests"), where("status", "==", "pending"))),
      ]);
      setStats({
        totalTeachers: total.data().count,
        activeTeachers: active.data().count,
        trialTeachers: trial.data().count,
        expiredTeachers: expired.data().count,
        totalStudents: students.data().count,
        pendingPayments: pending.data().count,
      });
    }
    load();
  }, []);

  return (
    <main className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">لوحة تحكم Owner</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <StatCard label="إجمالي المدرسين" value={stats.totalTeachers} />
        <StatCard label="المدرسون النشطون" value={stats.activeTeachers} />
        <StatCard label="المدرسون في Trial" value={stats.trialTeachers} />
        <StatCard label="اشتراكات منتهية" value={stats.expiredTeachers} />
        <StatCard label="إجمالي الطلاب" value={stats.totalStudents} />
        <StatCard label="طلبات دفع جديدة" value={stats.pendingPayments} />
      </div>
      <p className="text-sm text-gray-400 mt-8">
        صفحات إدارة المدرسين والطلبات (/admin/teachers, /admin/payment-requests) تُبنى على نفس نمط الحماية هنا.
      </p>
    </main>
  );
}

export default function OwnerDashboard() {
  return (
    <RequireRole allow={["owner"]}>
      <OwnerDashboardInner />
    </RequireRole>
  );
}
