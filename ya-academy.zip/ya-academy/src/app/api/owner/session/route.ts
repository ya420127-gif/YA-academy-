import { NextRequest, NextResponse } from "next/server";
import { adminAuth } from "@/lib/firebaseAdmin";

// نقطة السيرفر الوحيدة المسؤولة عن ضبط كوكي الجلسة لصفحات /owner و /admin
// التحقق من role يتم هنا على السيرفر عبر verifyIdToken — لا يمكن تزويره من العميل
export async function POST(req: NextRequest) {
  const { idToken } = await req.json();
  if (!idToken) return NextResponse.json({ error: "missing token" }, { status: 400 });

  try {
    const decoded = await adminAuth.verifyIdToken(idToken, true);
    const role = decoded.role as string | undefined;

    if (role !== "owner" && role !== "admin") {
      return NextResponse.json({ error: "forbidden" }, { status: 403 });
    }

    const res = NextResponse.json({ ok: true });
    res.cookies.set("ya_role", role, {
      httpOnly: true,
      secure: true,
      sameSite: "strict",
      maxAge: 60 * 60 * 8, // 8 ساعات
      path: "/",
    });
    return res;
  } catch {
    return NextResponse.json({ error: "invalid token" }, { status: 401 });
  }
}
