import { NextRequest, NextResponse } from "next/server";
import { adminDb } from "@/lib/firebaseAdmin";

const SUBSCRIPTION_DAYS = 30;

// اعتماد طلب الدفع وتفعيل حساب المدرس — منطق حساس يُنفَّذ على السيرفر حصريًا
export async function POST(req: NextRequest) {
  const role = req.cookies.get("ya_role")?.value;
  if (role !== "owner" && role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const { requestId } = await req.json();
  const reqRef = adminDb.collection("paymentRequests").doc(requestId);
  const reqSnap = await reqRef.get();
  if (!reqSnap.exists) return NextResponse.json({ error: "not found" }, { status: 404 });

  const { teacherId } = reqSnap.data() as { teacherId: string };
  const now = new Date();
  const end = new Date(now.getTime() + SUBSCRIPTION_DAYS * 24 * 60 * 60 * 1000);

  const batch = adminDb.batch();
  batch.update(reqRef, { status: "approved", reviewedAt: now.toISOString() });
  batch.update(adminDb.collection("teachers").doc(teacherId), {
    accountStatus: "active",
    subscriptionStartDate: now.toISOString(),
    subscriptionEndDate: end.toISOString(),
  });
  batch.set(adminDb.collection("notifications").doc(), {
    userId: teacherId,
    type: "subscription_activated",
    message: "تم تفعيل اشتراكك لمدة 30 يومًا",
    createdAt: now.toISOString(),
    read: false,
  });

  await batch.commit();
  return NextResponse.json({ ok: true });
}
