"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";

/**
 * يحمي أي صفحة بحيث لا يدخلها إلا صاحب الدور المسموح.
 * هذا حماية على مستوى الواجهة فقط للتوجيه (UX) —
 * الحماية الحقيقية تُفرض دائمًا في firestore.rules وفي middleware.ts.
 */
export default function RequireRole({
  allow,
  children,
}: {
  allow: Array<"owner" | "admin" | "teacher" | "student">;
  children: React.ReactNode;
}) {
  const { user, role, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user || !role || !allow.includes(role)) {
      // إذا حاول Teacher/Student فتح /owner أو /admin يُعاد توجيهه لصفحته المناسبة
      if (role === "teacher") router.replace("/teacher/dashboard");
      else if (role === "student") router.replace("/student/dashboard");
      else if (role === "owner") router.replace("/owner");
      else router.replace("/");
    }
  }, [loading, user, role, allow, router]);

  if (loading || !role || !allow.includes(role)) {
    return <div className="p-8 text-center text-gray-500">جاري التحقق من الصلاحيات...</div>;
  }

  return <>{children}</>;
}
