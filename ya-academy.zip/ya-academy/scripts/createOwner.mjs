/**
 * سكربت إنشاء أول حساب Owner — يُشغَّل يدويًا من السيرفر/الطرفية فقط.
 * لا يوجد أي مسار HTTP أو نموذج Frontend لإنشاء Owner.
 *
 * الاستخدام:
 *   OWNER_EMAIL=you@example.com OWNER_PASSWORD='StrongPass!23' npm run create-owner
 *
 * المتطلبات: نفس متغيرات بيئة firebase-admin (FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY)
 */
import { initializeApp, cert } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

const email = process.env.OWNER_EMAIL;
const password = process.env.OWNER_PASSWORD;

if (!email || !password) {
  console.error("❌ يجب تمرير OWNER_EMAIL و OWNER_PASSWORD كمتغيرات بيئة.");
  process.exit(1);
}

const app = initializeApp({
  credential: cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
  }),
});

const auth = getAuth(app);
const db = getFirestore(app);

async function main() {
  // امنع إنشاء أكثر من Owner واحد بالخطأ
  const existing = await db.collection("users").where("role", "==", "owner").limit(1).get();
  if (!existing.empty) {
    console.error("❌ يوجد بالفعل حساب Owner مسجل. أوقف العملية.");
    process.exit(1);
  }

  const userRecord = await auth.createUser({ email, password, emailVerified: true });

  // custom claim هو مصدر الحقيقة للصلاحيات — تُقرأ في Security Rules وفي الـ Middleware
  await auth.setCustomUserClaims(userRecord.uid, { role: "owner" });

  await db.collection("users").doc(userRecord.uid).set({
    role: "owner",
    email,
    createdAt: new Date().toISOString(),
  });

  console.log("✅ تم إنشاء حساب Owner بنجاح. uid:", userRecord.uid);
  console.log("سجّل الدخول من /owner-login بهذا البريد وكلمة المرور.");
  process.exit(0);
}

main().catch((err) => {
  console.error("فشل إنشاء Owner:", err);
  process.exit(1);
});
